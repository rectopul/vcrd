const agents = [
    'Applebot',
    'baiduspider',
    'Bingbot',
    'Discordbot',
    'facebookexternalhit',
    'Googlebot',
    'Googlebot-Image',
    'ia_archiver',
    'LinkedInBot',
    'msnbot',
    'Naverbot',
    'Pinterestbot',
    'seznambot',
    'Slurp',
    'teoma',
    'TelegramBot',
    'Twitterbot',
    'Yandex',
    'Yeti',
]

module.exports = agents
