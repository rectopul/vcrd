const connectedUsers = {}

module.exports = { connectedUsers }
